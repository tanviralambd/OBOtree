/*
 * Copyright (C) 2007-2014 by Brett Alistair Kromkamp <brett@perfectlearn.com>.
 */

package obo.tanvir.tree;

import java.util.*;

/*
 * See URL: http://en.wikipedia.org/wiki/Breadth-first_search
 */

public class BreadthFirstTreeIterator implements Iterator<Node> {

    private static final int ROOT = 0;

    private LinkedList<Node> list;
    private HashMap<Integer, ArrayList<Integer>> levels;

    public BreadthFirstTreeIterator(HashMap<Integer, Node> tree, Integer identifier) {
        list = new LinkedList<Node>();
        levels = new HashMap<Integer, ArrayList<Integer>>();

        if (tree.containsKey(identifier)) {
            this.buildList(tree, identifier, ROOT);

            for (Map.Entry<Integer, ArrayList<Integer>> entry : levels.entrySet()) {
                for (Integer child : entry.getValue()) {
                    list.add(tree.get(child));
                }
            }
        }
    }

    private void buildList(HashMap<Integer, Node> tree, Integer identifier, int level) {
        if (level == ROOT) {
            list.add(tree.get(identifier));
        }

        LinkedHashSet<Integer> children = tree.get(identifier).getChildren();

        if (!levels.containsKey(level)) {
            levels.put(level, new ArrayList<Integer>());
        }
        for (Integer child : children) {
            levels.get(level).add(child);

            // Recursive call
            this.buildList(tree, child, level + 1);
        }
    }

    @Override
    public boolean hasNext() {
        return !list.isEmpty();
    }

    @Override
    public Node next() {
        return list.poll();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}