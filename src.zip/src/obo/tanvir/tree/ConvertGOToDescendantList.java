package obo.tanvir.tree;



import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class ConvertGOToDescendantList {


	/*
	 *  Parameters
	 */
	String fnmParentChildBP;
	String fnmParentChildMF;
	String fnmParentChildCC;

	String fnmInputList;
	String fnmOutList;


	/*
	 *  Implementation variables
	 */

	Tree treeBP = new Tree();
	Tree treeMF = new Tree();
	Tree treeCC = new Tree();

	Vector<String> vectAll;
	String tmp[];

	Integer curID, curParent;


	Set<Integer> getAllDescent_applyDFS(Integer startNode)
	{



		Set<Integer> setResultTerms = new LinkedHashSet<Integer>();
		setResultTerms.add(  startNode   );

		Iterator<Node> depthIterator;

		// BP
		depthIterator = treeBP.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add( node.getIdentifier()   );
		}

		// MF
		depthIterator = treeMF.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add( node.getIdentifier()   );
		}

		// CC
		depthIterator = treeCC.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add(   node.getIdentifier()   );
		}



		return setResultTerms;
	}

	void loadAll3FullTrees()
	{

		/*
		 *  BP
		 */
		System.out.println("Loading tree: BP");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildBP);
		treeBP = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeBP.addNode(curID);
			}else
			{
				treeBP.addNode(curID, curParent);
			}

		}


		/*
		 *  MF
		 */
		System.out.println("Loading tree: MF");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildMF);
		treeMF = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeMF.addNode(curID);
			}else
			{
				treeMF.addNode(curID, curParent);
			}

		}


		/*
		 *  CC
		 */
		System.out.println("Loading tree: CC");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildCC);
		treeCC = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeCC.addNode(curID);
			}else
			{
				treeCC.addNode(curID, curParent);
			}

		}



	}


	void convertKnownMaping_IsaMapping()
	{

		CommonFunction.crateBlankFile(this.fnmOutList);
		int writeSize=1000;

		Vector<String> vectListUniprot = CommonFunction.readlinesOfAfile(this.fnmInputList);
		StringBuffer resBuf = new StringBuffer();


		String  curgo;
		String tmp[] , tmpGO[];
		int i=0;
		for( i=1 ; i< vectListUniprot.size()  ;i++)
		{

			tmp = ConstantValue.patTab.split(vectListUniprot.get(i));

			curgo = tmp[0];



			Set<Integer> setDescendants = new LinkedHashSet<Integer>();



			setDescendants.addAll(   getAllDescent_applyDFS(  CommonFunction.GO_StandardName_Integer( curgo)   )  );



			/*
			 *  Write the result for 1 gene
			 */
			resBuf.append( curgo + "\t" );
			Integer[] arr = (Integer[]) setDescendants.toArray(new Integer  [setDescendants.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(   CommonFunction.GO_Integer_StandardName( arr[c] )+  "\n");
				else
					resBuf.append(   CommonFunction.GO_Integer_StandardName( arr[c] ) + ",");

			} 


			if(i%writeSize ==0)
			{
				System.out.println("Work done for GO no: " + i);
				CommonFunction.writeContentToFileAppendInNewLine( this.fnmOutList, resBuf+"");
				resBuf = new StringBuffer();
			}


		} // iterate for each uniprot gene



		if( (i-1)%writeSize !=0)
		{
			System.out.println("Work done for GO no: " + i);
			CommonFunction.writeContentToFileAppendInNewLine( this.fnmOutList, resBuf+"");
			resBuf = new StringBuffer();
		}


	}


	void doProcessing(){

		loadAll3FullTrees();



		convertKnownMaping_IsaMapping();


	}


	public ConvertGOToDescendantList(String fnmParentChildBP,
			String fnmParentChildMF, String fnmParentChildCC,
			String fnmInputList, String fnmOutList) {
		super();
		this.fnmParentChildBP = fnmParentChildBP;
		this.fnmParentChildMF = fnmParentChildMF;
		this.fnmParentChildCC = fnmParentChildCC;
		this.fnmInputList = fnmInputList;
		this.fnmOutList = fnmOutList;
	}





	public static void main(String[] args) {

		ConvertGOToDescendantList obj = new ConvertGOToDescendantList(args[0], args[1], args[2], args[3] , args[4]);

//		ConvertGOToISAlist obj = new ConvertGOToISAlist("go-basic.obo.txt.BP.parentchild", "go-basic.obo.txt.MF.parentchild", "go-basic.obo.txt.CC.parentchild", "go-basic.obo.tsv" , "go-basic.obo.tsv.isa"  );

		obj.doProcessing();

	}


}

