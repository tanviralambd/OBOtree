/*
 * Copyright (C) 2007-2014 by Brett Alistair Kromkamp <brett@perfectlearn.com>.
 */

package obo.tanvir.tree;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class Node {

    private Integer identifier;
    private LinkedHashSet<Integer> children;

    // Constructor
    public Node(Integer identifier) {
        this.identifier = identifier;
        children = new LinkedHashSet<Integer>();
    }

    // Properties
    public Integer getIdentifier() {
        return identifier;
    }

    public LinkedHashSet<Integer> getChildren() {
        return children;
    }

    // Public interface
    public void addChild(Integer identifier) {
        children.add(identifier);
    }
}
