package obo.tanvir.tree;

public enum TraversalStrategy {

	DEPTH_FIRST,
    BREADTH_FIRST
}
