package obo.tanvir.tree;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class WRONG_ConvertListToDescendentList {


	/*
	 *  Parameters
	 */
	String fnmParentChildBP;
	String fnmParentChildMF;
	String fnmParentChildCC;

	String fnmInputList;
	String fnmOutList;


	/*
	 *  Implementation variables
	 */

	Tree treeBP = new Tree();
	Tree treeMF = new Tree();
	Tree treeCC = new Tree();

	Vector<String> vectAll;
	String tmp[];

	Integer curID, curParent;


	Set<Integer> getAllDescent_applyDFS(Integer startNode)
	{



		Set<Integer> setResultTerms = new LinkedHashSet<Integer>();
		setResultTerms.add(  startNode   );
		
		Iterator<Node> depthIterator;

		// BP
		depthIterator = treeBP.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add( node.getIdentifier()   );
		}

		// MF
		depthIterator = treeMF.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add( node.getIdentifier()   );
		}

		// CC
		depthIterator = treeCC.iterator(startNode , TraversalStrategy.DEPTH_FIRST);
		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			setResultTerms.add(   node.getIdentifier()   );
		}



		return setResultTerms;
	}

	void loadAll3FullTrees()
	{

		/*
		 *  BP
		 */
		System.out.println("Loading tree: BP");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildBP);
		treeBP = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeBP.addNode(curID);
			}else
			{
				treeBP.addNode(curID, curParent);
			}

		}


		/*
		 *  MF
		 */
		System.out.println("Loading tree: MF");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildMF);
		treeMF = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeMF.addNode(curID);
			}else
			{
				treeMF.addNode(curID, curParent);
			}

		}


		/*
		 *  CC
		 */
		System.out.println("Loading tree: CC");
		vectAll = new Vector<String>();
		vectAll = CommonFunction.readlinesOfAfile(this.fnmParentChildCC);
		treeCC = new Tree();
		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );
			//if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				treeCC.addNode(curID);
			}else
			{
				treeCC.addNode(curID, curParent);
			}

		}



	}


	void convertKnownMaping_IsaMapping()
	{

		CommonFunction.crateBlankFile(this.fnmOutList);
		int writeSize=200;
		
		Vector<String> vectListUniprot = CommonFunction.readlinesOfAfile(this.fnmInputList);
		StringBuffer resBuf = new StringBuffer();
		

		String curLine, uniACC, uniName, goList;
		String tmp[] , tmpGO[];
		int i=0;
		for( i=0 ; i< vectListUniprot.size()  ;i++)
		{

			tmp = ConstantValue.patTab.split(vectListUniprot.get(i));
			uniACC = tmp[0];
			uniName = tmp[1];
			goList = tmp[2];

			tmpGO = ConstantValue.patSemiColon_Comma.split(goList);

			Set<Integer> setIsA = new LinkedHashSet<Integer>();


			for( int j=0; j<tmpGO.length;j++)
			{
				setIsA.addAll(   getAllDescent_applyDFS(  CommonFunction.GO_StandardName_Integer(tmpGO[j])   )  );
			}


			/*
			 *  Write the result for 1 gene
			 */
			resBuf.append(uniACC + "\t" + uniName + "\t");
			Integer[] arr = (Integer[]) setIsA.toArray(new Integer  [setIsA.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(   CommonFunction.GO_Integer_StandardName( arr[c] )+  "\n");
				else
					resBuf.append(   CommonFunction.GO_Integer_StandardName( arr[c] ) + ",");

			} 

			
			if(i%writeSize ==0)
			{
				System.out.println("Work done for gene no: " + i);
				CommonFunction.writeContentToFileAppendInNewLine( this.fnmOutList, resBuf+"");
				resBuf = new StringBuffer();
			}
			

		} // iterate for each uniprot gene



		if( (i-1)%writeSize !=0)
		{
			System.out.println("Work done for gene no: " + i);
			CommonFunction.writeContentToFileAppendInNewLine( this.fnmOutList, resBuf+"");
			resBuf = new StringBuffer();
		}

		
	}


	void doProcessing(){

		loadAll3FullTrees();



		convertKnownMaping_IsaMapping();


	}


	public WRONG_ConvertListToDescendentList(String fnmParentChildBP,
			String fnmParentChildMF, String fnmParentChildCC,
			String fnmInputList, String fnmOutList) {
		super();
		this.fnmParentChildBP = fnmParentChildBP;
		this.fnmParentChildMF = fnmParentChildMF;
		this.fnmParentChildCC = fnmParentChildCC;
		this.fnmInputList = fnmInputList;
		this.fnmOutList = fnmOutList;
	}





	public static void main(String[] args) {

		WRONG_ConvertListToDescendentList obj = new WRONG_ConvertListToDescendentList(args[0], args[1], args[2], args[3] , args[4]);


		obj.doProcessing();

	}


}
