package obo.tanvir.tree;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class ConvertListToISA_Descendant_list {


	String fnmGO_ISAlist;
	String fnmInputList;
	String fnmOutList;


	/*
	 *  Implementation variables
	 */


	LinkedHashMap<String, Set<String>> lhm_GO_ISA_Descendant_list = new LinkedHashMap<String, Set<String>>();


	void load_GO_ISA_Descendant_list()
	{
		lhm_GO_ISA_Descendant_list = CommonFunction.readlinesOfAfile_asMap_setValue(this.fnmGO_ISAlist, 0, 1);



	}


	void convertKnownMaping_IsaMapping()
	{

		CommonFunction.crateBlankFile(this.fnmOutList);
		int writeSize=1000;

		Vector<String> vectListUniprot = CommonFunction.readlinesOfAfile(this.fnmInputList);
		StringBuffer resBuf = new StringBuffer();


		String curLine, uniACC, uniName, goList;
		String tmp[] , tmpGO[];
		int i=0;
		for( i=0 ; i< vectListUniprot.size()  ;i++)
		{

			tmp = ConstantValue.patTab.split(vectListUniprot.get(i));
			uniACC = tmp[0];
			uniName = tmp[1];
			goList = tmp[2];

			tmpGO = ConstantValue.patSemiColon_Comma.split(goList);

			Set<String> setIsAdescendant = new LinkedHashSet<String>();


			for( int j=0; j<tmpGO.length;j++)
			{
				if( lhm_GO_ISA_Descendant_list.containsKey( tmpGO[j]     )  ){

					setIsAdescendant.addAll(   lhm_GO_ISA_Descendant_list.get( tmpGO[j]     )  );

				}
			}


			/*
			 *  Write the result for 1 gene
			 */
			resBuf.append(uniACC + "\t" + uniName + "\t");
			String[] arr = (String[]) setIsAdescendant.toArray(new String  [setIsAdescendant.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(    arr[c] +  "\n");
				else
					resBuf.append(    arr[c] + ConstantValue.seperatorList );

			} 


			if(i%writeSize ==0)
			{
				System.out.println("Work done for gene no: " + i);
				CommonFunction.writeContentToFileAppendInSameLine( this.fnmOutList, resBuf+"");
				resBuf = new StringBuffer();
			}


		} // iterate for each uniprot gene



		if( (i-1)%writeSize !=0)
		{
			System.out.println("Work done for gene no: " + i);
			CommonFunction.writeContentToFileAppendInSameLine( this.fnmOutList, resBuf+"");
			resBuf = new StringBuffer();
		}


	}


	void doProcessing(){

		System.out.println("Loading GO ISA/Descendant mapping");
		load_GO_ISA_Descendant_list();


		System.out.println("Now generating ISA mapping");
		convertKnownMaping_IsaMapping();

		System.out.println("KHALAS 3 column");
	}



	public ConvertListToISA_Descendant_list(String fnmGO_ISAlist,
			String fnmInputList, String fnmOutList) {
		super();
		this.fnmGO_ISAlist = fnmGO_ISAlist;
		this.fnmInputList = fnmInputList;
		this.fnmOutList = fnmOutList;
	}


	public static void main(String[] args) {

		ConvertListToISA_Descendant_list obj = new ConvertListToISA_Descendant_list(args[0], args[1], args[2]);


		obj.doProcessing();

	}


}
