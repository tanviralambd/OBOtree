package obo.tanvir.tree;


import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class GOtreeSearch {


	String fnmInput;
	String fnmOutput;

	Tree tree = new Tree();
	Vector<String> vectAll;
	String tmp[];

	Integer curID, curParent;


	
	
	
	public GOtreeSearch(String fnmInput, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOutput = fnmOutput;
	}



	Set<String> getAllDescent_applyDFS(Integer startNode)
	{

		Iterator<Node> depthIterator = tree.iterator(startNode, TraversalStrategy.DEPTH_FIRST); // Harry
		
		Set<String> setResultTerms = new LinkedHashSet<String>();
		setResultTerms.add( CommonFunction.GO_Integer_StandardName( startNode )  );
		
		

		while (depthIterator.hasNext()) {
			Node node = depthIterator.next();
			
//			System.out.println(  node.getIdentifier() );
			System.out.println( CommonFunction.GO_Integer_StandardName( node.getIdentifier() )  );
			
			setResultTerms.add( CommonFunction.GO_Integer_StandardName( node.getIdentifier() )  );
		}
		
		return setResultTerms;
	}



	void loadFullTree()
	{
		vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);

		tree = new Tree();

		for(int i=0 ; i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curParent = Integer.parseInt( tmp[0] );
			curID = Integer.parseInt( tmp[2] );


//			if(curParent.equals("-1"))
			if(curParent== ConstantValue.GO_ROOT)
			{
				tree.addNode(curID);
			}else
			{
				tree.addNode(curID, curParent);
			}


		}
	}

	void doProcessing()
	{

		loadFullTree();
		getAllDescent_applyDFS(71216);


	}


	void doProcessing1()
	{


//		Tree tree = new Tree();

		/*
		 * The second parameter for the addNode method is the identifier
		 * for the node's parent. In the case of the root node, either
		 * null is provided or no second parameter is provided.
		 */
//		tree.addNode("Harry");
//		tree.addNode("Jane", "Harry");
//		tree.addNode("Bill", "Harry");
//		tree.addNode("Joe", "Jane");
//		tree.addNode("Diane", "Jane");
//		tree.addNode("George", "Diane");
//		tree.addNode("Mary", "Diane");getAllDescent_applyDFS
//		tree.addNode("Mary", "Joe");
//		tree.addNode("Jill", "George");
//		tree.addNode("Carol", "Jill");
//		tree.addNode("Grace", "Bill");
//		tree.addNode("Mark", "Jane");
//
//		tree.display("Harry");
//
//		System.out.println("\n***** DEPTH-FIRST ITERATION *****");
//
//		// Default traversal strategy is 'depth-first'
//		Iterator<Node> depthIterator = tree.iterator("Diane"); // Harry
//
//		while (depthIterator.hasNext()) {
//			Node node = depthIterator.next();
//			System.out.println(node.getIdentifier());
//		}
//
//		System.out.println("\n***** BREADTH-FIRST ITERATION *****");
//
//		Iterator<Node> breadthIterator = tree.iterator("Harry", TraversalStrategy.BREADTH_FIRST);
//
//		while (breadthIterator.hasNext()) {
//			Node node = breadthIterator.next();
//			System.out.println(node.getIdentifier());
//		}
//

	}


	public static void main(String[] args) {

		GOtreeSearch obj = new GOtreeSearch("go-basic.obo.txt.BP.parentchild", "out.txt");

		long startTime = System.currentTimeMillis();
		
		obj.doProcessing();

		long endTime   = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println( "Total time: " + totalTime/1000.00 + " secs");

	}

}
