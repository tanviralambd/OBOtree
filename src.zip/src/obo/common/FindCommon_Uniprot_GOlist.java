package obo.common;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class FindCommon_Uniprot_GOlist {

	
	
	String fnmInput;
	String fnmRepository;
	String fnmOut;
	
	int key1Index,val1Index,key2Index,valu2Index;
	
	
	void doProcessing()
	{
		
		StringBuffer resBuf = new StringBuffer();
		
		LinkedHashMap<String, Set <String>> lhm_name_valueList1;
		LinkedHashMap<String, Set <String>> lhm_name_valueList2;
		
		
		lhm_name_valueList1 = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(this.fnmInput, this.key1Index, this.val1Index);
		lhm_name_valueList2 = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(this.fnmRepository, this.key2Index, this.valu2Index);
		
		
		
		  Set set = lhm_name_valueList1.entrySet();
          Iterator itr = set.iterator();
          while(itr.hasNext()){


              Map.Entry me = (Map.Entry) itr.next();
              String id1 = (String)me.getKey();
              Set goList1 = (Set<String>) me.getValue();
              
              
              if(lhm_name_valueList2.containsKey(id1))
              {
            	  
            	  Set goList2 = (Set<String>) lhm_name_valueList2.get(id1);
            	  
            	  Set intersection = new HashSet(goList1);
            	  intersection.retainAll(goList2);
            	  
            	  
            	  resBuf.append( id1 + "\t" +
            			  		goList1.size() + "\t" + 
            			  		goList2.size() + "\t" + 
            			  		intersection.size() + "\n"   
                  			  
            			  );
                    
            	  
              }else
              {
            	  System.out.println( id1 + "  does not exist in repository");
              }
              
              
              
             
          }
		
		
		
		CommonFunction.writeContentToFile(this.fnmOut, resBuf+"");
		
		
		
	}
	
	
	
	
//	public FindCommon_Uniprot_GOlist(String fnmInput, String fnmRepository,
//			String fnmOut) {
//		super();
//		this.fnmInput = fnmInput;
//		this.fnmRepository = fnmRepository;
//		this.fnmOut = fnmOut;
//	}


	
	


	public FindCommon_Uniprot_GOlist(String fnmInput, String fnmRepository,
			String fnmOut, int key1Index, int val1Index, int key2Index,
			int valu2Index) {
		super();
		this.fnmInput = fnmInput;
		this.fnmRepository = fnmRepository;
		this.fnmOut = fnmOut;
		this.key1Index = key1Index;
		this.val1Index = val1Index;
		this.key2Index = key2Index;
		this.valu2Index = valu2Index;
	}




	public static void main(String[] args) {
		
		FindCommon_Uniprot_GOlist obj = new FindCommon_Uniprot_GOlist( args[0], args[1] , args[2],
				Integer.parseInt( args[3] ), 	Integer.parseInt( args[4] ), 	Integer.parseInt(args[5] ), 	Integer.parseInt(args[6]) );
		
//		FindCommon_Uniprot_GOlist obj = new FindCommon_Uniprot_GOlist( "GO.adj.0.05.GOlist", "GO.adj.0.05.GOlist" , "GO.adj.0.05.GOlist.stat");
		
		obj.doProcessing();
		
		
	}
	
	
}
