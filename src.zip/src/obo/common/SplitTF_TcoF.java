package obo.common;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class SplitTF_TcoF {

	

	String fnameGene_TfTcof="merged.gene.tf.tcof";
	String fnmTcofList="TF_Tcof.Name.txt";

	String fnmOutputPrefix="FARNA";


	LinkedHashMap<String, Set <String>> lhm_GeneID_Proteins = new LinkedHashMap<String, Set <String>>();

	Set<String> setTcoF;

	void loadTcoFnames()
	{

		lhm_GeneID_Proteins = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(this.fnameGene_TfTcof, 0, 1);

		setTcoF = CommonFunction.readlinesOfAfileInSet(this.fnmTcofList , 1) ;




	}


	void splitResult()
	{
		
		StringBuffer resultGene_TF = new StringBuffer();
		StringBuffer resultGene_TcoF = new StringBuffer();
		
		StringBuffer tmp_TF = new StringBuffer();
		StringBuffer tmp_TcoF = new StringBuffer();
		
		int countCurTF, countCurTcoF;


		Set set = lhm_GeneID_Proteins.entrySet();
		System.out.println("Total Unique entry:" + set.size() ) ;
		Iterator itr = set.iterator();
		String curName;
		while(itr.hasNext()){


			tmp_TF = new StringBuffer();
			tmp_TcoF = new StringBuffer();
			countCurTF=0;
			countCurTcoF=0;
			
			Map.Entry me = (Map.Entry) itr.next();
			String geneid = (String)me.getKey();
			Set setProteins = (Set) me.getValue();
			
			System.out.println( "Working for gene: " + geneid + " has protein set elemen:" + setProteins.size());
			
			
			Iterator itrNames = setProteins.iterator();
			while( itrNames.hasNext())
			{
				curName= (String)itrNames.next() ;

				if(this.setTcoF.contains(curName))
				{
					tmp_TcoF.append(curName+";");
					countCurTcoF++;
					
				}else
				{
					tmp_TF.append(curName+";");
					countCurTF++;
					
				}


			}
			
			if(countCurTF >0)
			{
				resultGene_TF.append(geneid+"\t" + tmp_TF.substring(0,tmp_TF.length()-1)   + "\n");
			}
			if(countCurTcoF >0 )
			{
				resultGene_TcoF.append(geneid+"\t" + tmp_TcoF.substring(0,tmp_TcoF.length()-1)   + "\n");
			}
			
		}// iterating each line
		
		
		
		CommonFunction.writeContentToFile(this.fnmOutputPrefix+".tf",  resultGene_TF + "");
		
		CommonFunction.writeContentToFile(this.fnmOutputPrefix+".tcof",  resultGene_TcoF + "");
		
		



	}


	void doProcessing()
	{

		loadTcoFnames();

		splitResult();


	}


	
	
	

	public SplitTF_TcoF(String fnameGene_TfTcof, String fnmTcofList,
			String fnmOutputPrefix) {
		super();
		this.fnameGene_TfTcof = fnameGene_TfTcof;
		this.fnmTcofList = fnmTcofList;
		this.fnmOutputPrefix = fnmOutputPrefix;
	}


	public static void main(String[] args) {
		
		SplitTF_TcoF obj = new SplitTF_TcoF(args[0] ,args[1] , args[2]);
		
//		SplitTF_TcoF obj = new SplitTF_TcoF("merged.gene.tf.tcof","TF_Tcof.Name.txt", "FARNA");
		
		obj.doProcessing();

	}



}
