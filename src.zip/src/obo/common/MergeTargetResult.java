package obo.common;

public class MergeTargetResult {

	
	String fnm1;
	String fnm2;
	String fnmMerged;
	
	
	
	
	
	
	
	public MergeTargetResult(String fnm1, String fnm2, String fnmMerged) {
		super();
		this.fnm1 = fnm1;
		this.fnm2 = fnm2;
		this.fnmMerged = fnmMerged;
	}




	void doProcessing()
	{
		CommonFunction.mergeTwoLinkedHashMap(this.fnm1, this.fnm2, this.fnmMerged);
	}



	public static void main(String[] args) {
		
		
		MergeTargetResult obj = new MergeTargetResult(args[0], args[1], args[2]);
		
//		MergeTargetResult obj = new MergeTargetResult("a.txt", "b.txt", "c.txt");
		
		
		
		obj.doProcessing();
		
	}
	
	
	
}
