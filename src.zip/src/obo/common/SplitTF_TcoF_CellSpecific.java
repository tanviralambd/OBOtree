package obo.common;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import obo.folderoperation.FolderOperations;

public class SplitTF_TcoF_CellSpecific {

	

	
	String fnmTcofList="TF_Tcof.Name.txt";
	String foldResultsCAGE;
	String fnameGene_TfTcof="merged.gene.tf.tcof";
	String foldOutput;
	
	
	public SplitTF_TcoF_CellSpecific(String fnmTcofList,
			String foldResultsCAGE, String fnameGene_TfTcof, String foldOutput) {
		super();
		this.fnmTcofList = fnmTcofList;
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnameGene_TfTcof = fnameGene_TfTcof;
		this.foldOutput = foldOutput;
	}


	LinkedHashMap<String, Set <String>> lhm_GeneID_TcoFProteins ;

	Set<String> setAllTcoFdb;

	void loadTFTcoFofACell( String cellName, String absPathCell)
	{
		
		String fnmInput= absPathCell + "/" +this.fnameGene_TfTcof ;
		String fnmSameFile =  this.foldOutput + "/" + "TFTcoF_"   + cellName+".txt";
		
		lhm_GeneID_TcoFProteins = new LinkedHashMap<String, Set <String>>();

		lhm_GeneID_TcoFProteins = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(
				fnmInput, 0, 1);

		
		
		FolderOperations.copy_paste_file(fnmInput, fnmSameFile);
		
		

	}


	void splitResult( String curCell)
	{
		
		StringBuffer resultGene_TF = new StringBuffer();
		StringBuffer resultGene_TcoF = new StringBuffer();
		
		StringBuffer tmp_TF = new StringBuffer();
		StringBuffer tmp_TcoF = new StringBuffer();
		
		int countCurTF, countCurTcoF;


		Set set = lhm_GeneID_TcoFProteins.entrySet();
		System.out.println("Total Unique RNAs in this cell:" + set.size() ) ;
		Iterator itr = set.iterator();
		String curName;
		while(itr.hasNext()){


			tmp_TF = new StringBuffer();
			tmp_TcoF = new StringBuffer();
			countCurTF=0;
			countCurTcoF=0;
			
			Map.Entry me = (Map.Entry) itr.next();
			String geneid = (String)me.getKey();
			Set setProteins = (Set) me.getValue();
			
			System.out.println( "Working for gene: " + geneid + " has TF_TcoF protein set elemen:" + setProteins.size());
			
			
			Iterator itrNames = setProteins.iterator();
			while( itrNames.hasNext())
			{
				curName= (String)itrNames.next() ;

				if(this.setAllTcoFdb.contains(curName))
				{
					tmp_TcoF.append(curName+";");
					countCurTcoF++;
					
				}else
				{
					tmp_TF.append(curName+";");
					countCurTF++;
					
				}


			}
			
			if(countCurTF >0)
			{
				resultGene_TF.append(geneid+"\t" + tmp_TF.substring(0,tmp_TF.length()-1)   + "\n");
			}
			if(countCurTcoF >0 )
			{
				resultGene_TcoF.append(geneid+"\t" + tmp_TcoF.substring(0,tmp_TcoF.length()-1)   + "\n");
			}
			
		}// iterating each line
		
		
		
		CommonFunction.writeContentToFile(this.foldOutput + "/" + "TF_"   + curCell+".txt",  resultGene_TF + "");
		
		CommonFunction.writeContentToFile(this.foldOutput + "/"+ "TcoF_" + curCell+".txt",  resultGene_TcoF + "");
		
		



	}

	
	void workForOneCellLine( String curCellName, String absPathCell)
	{
		loadTFTcoFofACell(curCellName,absPathCell);
		splitResult(curCellName);
	}
	

	void workForAllCellLines()
	{


		FolderOperations.create_new_folder(this.foldOutput) ;

		String curInputFolderCellAbspath , curCellName;

		Vector<String> vectFolderCellline = FolderOperations.listFiles_Dir(foldResultsCAGE);



		/*
		 *  Iterate over all folders
		 */
		for(int i=0; i< vectFolderCellline.size() ;i++) // vectFolderCellline.size()
		{
			curCellName = vectFolderCellline.get(i);
			curInputFolderCellAbspath = this.foldResultsCAGE + "/" +  curCellName + "/" ;

			System.out.println("Working for cellline: " + curInputFolderCellAbspath);

			workForOneCellLine( curCellName ,  curInputFolderCellAbspath);
			
//			if(curCellName.equals("HEPG2"))
//			{
//				System.out.println("Work for it");
//			}
			
			
		}


	}

	void doProcessing()
	{

		setAllTcoFdb = CommonFunction.readlinesOfAfileInSet(this.fnmTcofList , 1) ;
		workForAllCellLines();
		


	}



	public static void main(String[] args) {
		
		SplitTF_TcoF_CellSpecific obj = new SplitTF_TcoF_CellSpecific(args[0] ,args[1] , args[2] , args[3]);
		
		
//		SplitTF_TcoF_CellSpecific obj = new SplitTF_TcoF_CellSpecific("TF_Tcof.Name.txt", "./CAGEresult/" ,"merged.gene.tf.tcof", "./outfold/");
		
		obj.doProcessing();

	}



}

