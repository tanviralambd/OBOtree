package obo.common;

import java.util.Vector;

import obo.constant.ConstantValue;

public class RenameLncRNA {

	String fnmInput;
	String fnmOutput;
	
	
	
	void doProcessing()
	{
		int index=0 ;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		StringBuffer buf = new StringBuffer();
		String tmp[];
		int noColumn;
		
		
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			noColumn = tmp.length;
			
			
			index = tmp[0].lastIndexOf('.');
			
			if(index>0)
			{
				tmp[0] = tmp[0].substring(0, index);
			}
			
			for(int c=0; c<noColumn-1;c++)
			{
				buf.append(tmp[c] + "\t" );
			}
			buf.append(tmp[noColumn-1]  + "\n");
			
		}
		
//		System.out.println("Writing result" + buf);
		CommonFunction.writeContentToFile(this.fnmOutput, buf+"");
		
	}
	
	
	
	
	public RenameLncRNA(String fnmInput, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOutput = fnmOutput;
	}




	public static void main(String[] args) {
		
		RenameLncRNA obj = new RenameLncRNA(args[0] , args[1]);
		
//		String input= "/run/media/tanviralam/Data/research/FARNA/Download/Transfac2015/lncRNA/lncRNA.GO.tsv";
//		String output= input+".tsv";
//		RenameLncRNA obj = new RenameLncRNA(input,output);
		
		
		
		obj.doProcessing();
		
	}
	
	
}
