package obo.common;

import java.util.Vector;

import obo.constant.ConstantValue;

public class SelectDiseaseFDR {

	
	
	String fin;
	String fout;
	
	int field1_based;
	double thrFDR;
	
	
	void doProcessing()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fin);
		
		StringBuffer result = new StringBuffer();
		result.append(vectAll.get(0) + "\n");
		
		String tmp[];
		double curVal;
		
		for(int i=1; i<vectAll.size();i++)
		{
		
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			curVal = Double.parseDouble(tmp[field1_based-1]);
			
			if(curVal <= thrFDR)
			{
				result.append(vectAll.get(i) + "\n");
				
			}
			
		}
		
		
		CommonFunction.writeContentToFile(this.fout, result+"");
		
	}
	
	
	
	
	public SelectDiseaseFDR(String fin, String fout, int field1_based,
			double thrFDR) {
		super();
		this.fin = fin;
		this.fout = fout;
		this.field1_based = field1_based;
		this.thrFDR = thrFDR;
	}




	public static void main(String[] args) {
		
		SelectDiseaseFDR obj = new SelectDiseaseFDR(args[0], args[1], 
				Integer.parseInt(args[2] ), 
				Double.parseDouble(args[3])  );
		
		
		obj.doProcessing();
		
	}
	
	
}
