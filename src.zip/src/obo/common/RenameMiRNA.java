package obo.common;



import java.util.Vector;

import obo.constant.ConstantValue;

public class RenameMiRNA {

	String fnmInput;
	String fnmOutput;
	
	
	
	void doProcessing()
	{
		int index=0 ;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		StringBuffer buf = new StringBuffer();
		String tmp[];
		int noColumn;
		
		
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			noColumn = tmp.length;
			
			
			index = tmp[0].indexOf('-');
			
			// Changer the column "table-hsa-mir-1291#9"
			if(index>0)
			{
				tmp[0] = tmp[0].substring( index+1);
			}
			
			// Add all column into Buffer
			for(int c=0; c<noColumn-1;c++)
			{
				buf.append(tmp[c] + "\t" );
			}
			buf.append(tmp[noColumn-1]  + "\n");
			
		}
		
//		System.out.println("Writing result" + buf);
		CommonFunction.writeContentToFile(this.fnmOutput, buf+"");
		
	}
	
	
	
	
	public RenameMiRNA(String fnmInput, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOutput = fnmOutput;
	}




	public static void main(String[] args) {
		
		RenameMiRNA obj = new RenameMiRNA(args[0] , args[1]);
		
//		String input= "/run/media/tanviralam/Data/research/FARNA/Download/Transfac2015/lncRNA/miRNA.GO.txt";
		
//		String input="miRNA.GO.tsv";
//		String output= input+".tsv";
//		RenameMiRNA obj = new RenameMiRNA(input,output);
		
		
		
		obj.doProcessing();
		
	}
	
	
}
