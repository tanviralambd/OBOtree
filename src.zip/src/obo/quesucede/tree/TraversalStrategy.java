package obo.quesucede.tree;

public enum TraversalStrategy {

	DEPTH_FIRST,
    BREADTH_FIRST
}
