package obo.quesucede.tree;

import java.util.Iterator;




public class App {
    public static void main(String[] args) {

    	Tree tree = new Tree();

        /*
         * The second parameter for the addNode method is the identifier
         * for the node's parent. In the case of the root node, either
         * null is provided or no second parameter is provided.
         */
    	
    	
//        tree.addNode("Harry");
//        tree.addNode("Jane", "Harry");
//        tree.addNode("Bill", "Harry");
//        tree.addNode("son", "Jane");
//        tree.addNode("son", "Bill");
        
//    	tree.addNode("R");
//    	tree.addNode("R2");
//    	tree.addNode("B", "R");
//        tree.addNode("J", "R");
//        tree.addNode("B", "R2");
//        tree.addNode("J", "R2");
//        tree.addNode("L", "B");
//        tree.addNode("L2", "J");
//        tree.addNode("L", "B");
//        tree.addNode("L2", "J");
//        

    	tree.addNode("L");
    	tree.addNode("L2");
    	
    	tree.addNode("B", "L");
        tree.addNode("B", "L2");
        tree.addNode("J", "L");
        tree.addNode("J", "L2");
    	tree.addNode("R", "B");
        tree.addNode("R", "J");
        tree.addNode("R2", "B");
        tree.addNode("R2", "J");
        
    	

//        tree.display("Harry");

        System.out.println("\n***** DEPTH-FIRST ITERATION *****");

        // Default traversal strategy is 'depth-first'
        Iterator<Node> depthIterator = tree.iterator("B"); // Harry

        while (depthIterator.hasNext()) {
            Node node = depthIterator.next();
            System.out.println(node.getIdentifier());
        }

//        System.out.println("\n***** BREADTH-FIRST ITERATION *****");
//
//        Iterator<Node> breadthIterator = tree.iterator("Harry", TraversalStrategy.BREADTH_FIRST);
//
//        while (breadthIterator.hasNext()) {
//            Node node = breadthIterator.next();
//            System.out.println(node.getIdentifier());
//        }
        
        
    }
}