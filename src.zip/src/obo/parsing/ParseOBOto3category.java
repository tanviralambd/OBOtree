package obo.parsing;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class ParseOBOto3category {


	String fnmInput;
	String fnmOut;


	/*
	 *  Variable related to each term
	 */
	int goID=-1 ,  useIt=1;
	Set<Integer> is_a ;
	String namespace="";

	StringBuffer bufBP= new StringBuffer();
	StringBuffer bufMF= new StringBuffer();
	StringBuffer bufCC= new StringBuffer();


	LinkedHashMap<Integer, String> lhm_go_namespace = new LinkedHashMap<Integer, String>();

	void initTreeRelatedVariable()
	{
		// resetting values
		goID=-1;
		namespace="";
		is_a= new LinkedHashSet<Integer>();
		useIt=1;
	}

	void doworkon1term(int childID, String namespaceOfChild, Set<Integer> is_aSet , int useIt)
	{

		
		if( useIt ==1)
		{
			if( namespaceOfChild.equals("biological_process") ) // type.equals("BP") && 
			{

				Integer[] arr = (Integer[]) is_aSet.toArray(new Integer[is_aSet.size()]);
				int setSize = arr.length;
				
				if(setSize==0)
				{
					bufBP.append( childID + "\t" + "BP" + "\t" + "-1" + "\n");
				}else
				{
					for(int c=0; c < setSize;c++)
					{
						bufBP.append( childID + "\t" + "BP" + "\t" + arr[c] + "\n");
					} 
				}
				


			}else if(  namespaceOfChild.equals("molecular_function") )  // type.equals("MF") &&
			{
				Integer[] arr = (Integer[]) is_aSet.toArray(new Integer[is_aSet.size()]);
				int setSize = arr.length;
				
				
				if(setSize==0)
				{
					bufMF.append( childID + "\t" + "MF" + "\t" + "-1" + "\n");
				}else
				{
					for(int c=0; c < setSize;c++)
					{
						bufMF.append( childID + "\t" + "MF" + "\t" + arr[c] + "\n");
					} 
				}
				
				
				
			}else if(  namespaceOfChild.equals("cellular_component")  ) // type.equals("CC") && 
			{
				Integer[] arr = (Integer[]) is_aSet.toArray(new Integer[is_aSet.size()]);
				int setSize = arr.length;
				
				
				if(setSize==0)
				{
					bufCC.append( childID + "\t" + "CC" + "\t" + "-1" + "\n");
				}else
				{
					for(int c=0; c < setSize;c++)
					{
						bufCC.append( childID + "\t" + "CC" + "\t" + arr[c] + "\n");
					} 
				}
				
				
				
			}




		}else
		{
			System.out.println(childID + "\t" + "OBSOLETE");
		}





		initTreeRelatedVariable();



	}




	void doworkon1termTest(int childID, String namespaceOfChild, Set<Integer> is_aSet , int useIt)
	{

		String namespaceOfParent="";
		
		if( useIt ==1)
		{
			Integer[] arrParent = (Integer[]) is_aSet.toArray(new Integer[is_aSet.size()]);
			int setSize = arrParent.length;
			if(setSize==0)
			{
				switch (namespaceOfChild) {
				case "biological_process":
					bufBP.append( childID + "\t" + "BP" + "\t" + "-1" + "\n");
					break;
				case "molecular_function":
					bufMF.append( childID + "\t" + "MF" + "\t" + "-1" + "\n");			
					break;
				case "cellular_component":
					bufCC.append( childID + "\t" + "CC" + "\t" + "-1" + "\n");
					break;
	

				default:
					break;
				}
				
				
			}else
			{
				
				for(int c=0; c < setSize;c++)
				{
					namespaceOfParent = lhm_go_namespace.get(arrParent[c]);
					
					switch (namespaceOfParent) {
					case "biological_process":
						bufBP.append( childID + "\t" + "BP" + "\t" + arrParent[c] + "\n");
						break;
					case "molecular_function":
						bufMF.append( childID + "\t" + "MF" + "\t" + arrParent[c] + "\n");			
						break;
					case "cellular_component":
						bufCC.append( childID + "\t" + "CC" + "\t" + arrParent[c] + "\n");
						break;
		

					default:
						break;
					}
					
					
					
				}
				
				
			}
			
			




		}else
		{
			System.out.println(childID + "\t" + "OBSOLETE");
		}





		initTreeRelatedVariable();



	}


	
	void writeEachCategory()
	{
		CommonFunction.writeContentToFile(this.fnmOut + ".BP", bufBP+"");
		CommonFunction.writeContentToFile(this.fnmOut + ".MF", bufMF+"");
		CommonFunction.writeContentToFile(this.fnmOut + ".CC", bufCC+"");


	}

	void loadAllGOBasedonChildNamespace()
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfileKeepBlankLines(this.fnmInput);

		String curLine , curLineID , curLineNamespace;
		String tmp[];
		int parent;
		int totalTerm=0;
		int i=0;

		try {
			
			initTreeRelatedVariable();

			for(i=0;  i<vectAll.size() ;i++)
			{

				curLine = vectAll.get(i);
				
				if( curLine.startsWith("[Typedef]") ) {
					break;
				}

				if(curLine.startsWith("[Term]"))
				{


					if(totalTerm !=0) // this is the first time; No need to use it
					{
						doworkon1term(goID , namespace , is_a , useIt);

					}

					totalTerm++;

					/*
					 *  id: GO:0003682
					 */
					i++;
					curLineID = vectAll.get(i);
					tmp = ConstantValue.patColonWhitespace.split(curLineID);
					goID = Integer.parseInt(tmp[2]);


					/*
					 *  namespace: molecular_function
					 */
					i=i+2;
					curLineNamespace = vectAll.get(i);
					tmp = ConstantValue.patColonWhitespace.split(curLineNamespace);
					namespace = tmp[1];
				}


				/*
				 *  is_a: GO:0005488 ! binding
				 */
				else if(curLine.startsWith("is_a:"))
				{	
					tmp = ConstantValue.patColonWhitespace.split(curLine);

					parent = Integer.parseInt(tmp[2]); 
					is_a.add(parent) ;

				}

				/*
				 *  is_obsolete: true
				 */

				else if(curLine.startsWith("is_obsolete:"))
				{	
					useIt = 0;

				}

				/*
				 *  relationship: part_of GO:0007267 ! cell-cell signaling

				 */
				else if(  curLine.startsWith("relationship: part_of") )
				{
					tmp = ConstantValue.patColonWhitespace.split(curLine);

					parent = Integer.parseInt(tmp[3]); 
					is_a.add(parent) ;
					
					System.out.println("part_of: " + curLine);
					
				}
				
				/*
				 * [Term]
				 * id: GO:1901858
				 *  intersection_of: GO:0065007 ! biological regulation
				 *  intersection_of: regulates GO:0032042 ! mitochondrial DNA metabolic process
				 *  relationship: regulates GO:0032042 ! mitochondrial DNA metabolic process
				 *  
				 *  
				 *  intersection_of: positively_regulates GO:0004518 ! nuclease activity
				 *  relationship: positively_regulates GO:0004518 ! nuclease activity
				 */
				
				else if(  curLine.startsWith("relationship:") ||
						curLine.startsWith("intersection_of:")
						
						)
				{
					tmp = ConstantValue.patWhiteSpace.split(curLine);

					if( tmp[1].startsWith("GO:"))
					{
						tmp = ConstantValue.patColonWhitespace.split(tmp[1]);
						parent = Integer.parseInt(tmp[1]); 
						is_a.add(parent) ;
						System.out.println("relationship: " + curLine);
					}else if ( tmp[2].startsWith("GO:"))
					{
						tmp = ConstantValue.patColonWhitespace.split(tmp[2]);
						parent = Integer.parseInt(tmp[1]); 
						is_a.add(parent) ;
						System.out.println("relationship: " + curLine);
					}
					
					
					
				}


			}

			/*
			 *  For last [Term]
			 */

			doworkon1term(goID , namespace , is_a , useIt);

			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERR for:" + vectAll.get(i));
		}
		
		
	}


	
	void loadAllGOBasedOnParentNamespace()
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfileKeepBlankLines(this.fnmInput);

		String curLine , curLineID , curLineNamespace;
		String tmp[];
		int parent;
		int totalTerm=0;
		int i=0;

		try {
			
			initTreeRelatedVariable();

			for(i=0;  i<vectAll.size() ;i++)
			{

				curLine = vectAll.get(i);
				
				if( curLine.startsWith("[Typedef]") ) {
					break;
				}

				if(curLine.startsWith("[Term]"))
				{


					if(totalTerm !=0) // this is the first time; No need to use it
					{
						doworkon1termTest(goID , namespace , is_a , useIt);

					}

					totalTerm++;

					/*
					 *  id: GO:0003682
					 */
					i++;
					curLineID = vectAll.get(i);
					tmp = ConstantValue.patColonWhitespace.split(curLineID);
					goID = Integer.parseInt(tmp[2]);


					/*
					 *  namespace: molecular_function
					 */
					i=i+2;
					curLineNamespace = vectAll.get(i);
					tmp = ConstantValue.patColonWhitespace.split(curLineNamespace);
					namespace = tmp[1];
				}


				/*
				 *  is_a: GO:0005488 ! binding
				 */
				else if(curLine.startsWith("is_a:"))
				{	
					tmp = ConstantValue.patColonWhitespace.split(curLine);

					parent = Integer.parseInt(tmp[2]); 
					is_a.add(parent) ;

				}

				/*
				 *  is_obsolete: true
				 */

				else if(curLine.startsWith("is_obsolete:"))
				{	
					useIt = 0;

				}

				/*
				 *  relationship: part_of GO:0007267 ! cell-cell signaling

				 */
				else if(  curLine.startsWith("relationship: part_of") )
				{
					tmp = ConstantValue.patColonWhitespace.split(curLine);

					parent = Integer.parseInt(tmp[3]); 
					is_a.add(parent) ;
					
					System.out.println("part_of: " + curLine);
					
				}
				
				// Added Today
				
				/*
				 * [Term]
				 * id: GO:1901858
				 *  intersection_of: GO:0065007 ! biological regulation
				 *  intersection_of: regulates GO:0032042 ! mitochondrial DNA metabolic process
				 *  relationship: regulates GO:0032042 ! mitochondrial DNA metabolic process
				 *  
				 *  
				 *  intersection_of: positively_regulates GO:0004518 ! nuclease activity
				 *  relationship: positively_regulates GO:0004518 ! nuclease activity
				 */
				
				else if(  curLine.startsWith("relationship:") ||
						curLine.startsWith("intersection_of:")
						
						)
				{
					tmp = ConstantValue.patWhiteSpace.split(curLine);

					if( tmp[1].startsWith("GO:"))
					{
						tmp = ConstantValue.patColonWhitespace.split(tmp[1]);
						parent = Integer.parseInt(tmp[1]); 
						is_a.add(parent) ;
						System.out.println("relationship: " + curLine);
					}else if ( tmp[2].startsWith("GO:"))
					{
						tmp = ConstantValue.patColonWhitespace.split(tmp[2]);
						parent = Integer.parseInt(tmp[1]); 
						is_a.add(parent) ;
						System.out.println("relationship: " + curLine);
					}
					
					
					
				}
				


			}

			/*
			 *  For last [Term]
			 */

			doworkon1termTest(goID , namespace , is_a , useIt);

			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERR for:" + vectAll.get(i));
		}
		
		
	}


	
	void loadNamespaceForAllGO()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfileKeepBlankLines(this.fnmInput);

		String curLine , curLineNamespace;
		Integer curGoID;
		String tmp[];
		int parent;
		int totalTerm=0;
		int i=0;

		try {
			

			for(i=0;  i<vectAll.size() ;i++)
			{

				curLine = vectAll.get(i);
				
				if( curLine.startsWith("[Typedef]") ) {
					break;
				}

				if(curLine.startsWith("[Term]"))
				{



					totalTerm++;

					/*
					 *  id: GO:0003682
					 */
					i++;
					
					tmp = ConstantValue.patColonWhitespace.split(vectAll.get(i));
					curGoID = Integer.parseInt(tmp[2]);


					/*
					 *  namespace: molecular_function
					 */
					i=i+2;
					tmp = ConstantValue.patColonWhitespace.split(vectAll.get(i));
					curLineNamespace = tmp[1];
					
					
					lhm_go_namespace.put(curGoID, curLineNamespace);
				}



			}

			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERR for:" + vectAll.get(i));
		}
		
	}

	public ParseOBOto3category(String fnmInput, String fnmOut) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOut = fnmOut;
	}


	void doProcessing()
	{
		loadNamespaceForAllGO();
		
		// SEE: GO:0000030 . It can not handle 1 GO term in multiple namespace
//		loadAllGOBasedonChildNamespace();
		
		
		loadAllGOBasedOnParentNamespace();
		writeEachCategory();

	}

	public static void main(String[] args) {


		ParseOBOto3category obj = new ParseOBOto3category(args[0], args[1]) ;


//		ParseOBOto3category obj = new ParseOBOto3category("sample.obo", "sample.obo.txt" ) ;
		
//		ParseOBOto3category obj = new ParseOBOto3category("go-basic.obo", "go-basic.obo.txt" ) ;
//		ParseOBOto3category obj = new ParseOBOto3category("go.obo", "go.obo.txt" ) ;
		obj.doProcessing();

	}

}
