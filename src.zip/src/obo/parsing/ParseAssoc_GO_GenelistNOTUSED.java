package obo.parsing;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class ParseAssoc_GO_GenelistNOTUSED {

	
	
	String fnmAssoc;
	String fnmOut;
	
	
	LinkedHashMap<String, Set<String>> lhm_GO_UniName = new LinkedHashMap<String, Set<String>>();

	
	void doProcessing()
	{

		generate_Uniname_GOlist();
		writeList_GO_Genelist();
		
	}
	
	
	void generate_Uniname_GOlist()
	{


		String tmp[];
		String curLine;
		int skipheadTotLine = 33;
		String curRes;

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAssoc);
		String curUniAcc, curUniName, curGO="";
		String source="";
		int totColumn;

		StringBuffer resBuf = new StringBuffer();

		for( int i= skipheadTotLine;  i<vectAll.size(); i++)
		{

			curLine = vectAll.get(i);
			if(curLine.startsWith("!"))
			{
				continue;
			}

			tmp = ConstantValue.patTab.split(curLine);
			totColumn = tmp.length;

			source = tmp[0];
			curUniAcc = tmp[1];

			if( !source.equals("UniProtKB") )
				continue;

			//			curGO = tmp[3];
			// There are some cases where GO:NNNNNNN is not at 4th tab-delimitted column

			for( int j=2; j<totColumn ;j++)
			{
				if( tmp[j].startsWith("GO:"))
				{
					curGO = tmp[j];
					break;
				}

			}




				
		
			
				curUniName = tmp[totColumn - 4] ;
				
				if( lhm_GO_UniName.containsKey(  curGO))
				{
					Set curGeneList = lhm_GO_UniName.get(curGO);
					curGeneList.add(curUniName);
					lhm_GO_UniName.put(curGO, curGeneList  );
				}else{
					Set curGeneList = new LinkedHashSet<String>();
					curGeneList.add(curUniName);
					lhm_GO_UniName.put( curGO , curGeneList );
				}
				
				
			
			
			

		}




	}
	
	void writeList_GO_Genelist()
	{
		

		String uniName;
		StringBuffer resBuf = new StringBuffer();
		

		Set set = lhm_GO_UniName.entrySet();
		System.out.println("Total Unique GO terms in GO file:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String curGO = (String)me.getKey();
			Set  protNameList  = (Set<String>) me.getValue();
		

			String[] arr = (String[]) protNameList.toArray(new String[protNameList.size()]);
			int setSize = arr.length;
			
			resBuf.append(curGO + "\t" + setSize + "\t"  );

			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(arr[c]+ "\n");
				else
					resBuf.append(arr[c]+ ConstantValue.seperatorList );

			} 


		}


		CommonFunction.writeContentToFile(this.fnmOut, resBuf+"");
		
		
	}
	
	
	
	
	public ParseAssoc_GO_GenelistNOTUSED(String fnmAssoc, String fnmOut) {
		super();
		this.fnmAssoc = fnmAssoc;
		this.fnmOut = fnmOut;
	}


	public static void main(String[] args) {
		
		
		ParseAssoc_GO_GenelistNOTUSED obj = new ParseAssoc_GO_GenelistNOTUSED(args[0], args[1]);
		
		obj.doProcessing();
		
	}
	
	
	
	
	
}
