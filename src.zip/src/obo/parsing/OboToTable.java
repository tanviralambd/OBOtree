package obo.parsing;

import java.util.Vector;


import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class OboToTable {

	String fnmOboFormat="go-basic.obo";
	String fnmOUt="go-basic.obo.tsv";	

	int skipTopLine=28;
	String termStart="[Term]";
	Vector<String > vectAll = new Vector<String>();



	void init(String obo , String fout)
	{
		this.fnmOboFormat = obo;
		this.fnmOUt = fout;
	}

	void loadAll()
	{
		vectAll = CommonFunction.readlinesOfAfile(this.fnmOboFormat);
		System.out.println("Total LIne in .obo file:  " + vectAll.size());
	}

	void doParsing()
	{


		StringBuffer bufFinal = new StringBuffer();

		bufFinal.append("ID" + "\t" + "Description"  + "\t" + "Category"  + "\t" + "is_a"  + "\t" + "part_of"   + "\n" );

		String curLine ,curLineAfterTrim;
		String termStart,termEnd;

		for(int i=0;  i<vectAll.size() ;i++)
		{
			curLine = vectAll.get(i);
			curLineAfterTrim = curLine.trim();
			if(curLine.startsWith(this.termStart))
			{
				//				System.out.println("Term found at line no: " + i);
				bufFinal.append( checkOneTerm(i) + "\n");
			}


		}


		CommonFunction.writeContentToFile(this.fnmOUt, bufFinal+"");
	}


	//	
	//	[Term]
	//			id: GO:2001316
	//			name: kojic acid metabolic process
	//			namespace: biological_process
	//			def: "The chemical reactions and pathways involving kojic acid." [CHEBI:43572, GOC:di]
	//			synonym: "5-hydroxy-2-(hydroxymethyl)-4H-pyran-4-one metabolic process" EXACT [CHEBI:43572, GOC:obol]
	//			synonym: "5-hydroxy-2-(hydroxymethyl)-4H-pyran-4-one metabolism" EXACT [CHEBI:43572, GOC:obol]
	//			synonym: "C6H6O4 metabolic process" RELATED [CHEBI:43572, GOC:obol]
	//			synonym: "C6H6O4 metabolism" RELATED [CHEBI:43572, GOC:obol]
	//			synonym: "kojic acid metabolism" EXACT [GOC:obol]
	//			is_a: GO:0034308 ! primary alcohol metabolic process
	//			is_a: GO:0042180 ! cellular ketone metabolic process
	//			is_a: GO:0046483 ! heterocycle metabolic process
	//			is_a: GO:1901360 ! organic cyclic compound metabolic process

	/*
	 * startIndex = line number for [Term]
	 */
	String checkOneTerm( int startIndex)
	{
		String resultLine= new String();


		boolean foundEnd = false;

		int curIndex = startIndex+1;

		String curLine , curLineTrim;
		String tmp[];


		String id="",name="",namespace="";
		StringBuffer bufISA = new StringBuffer();
		StringBuffer bufPartOf = new StringBuffer();

		while(!foundEnd)
		{
			curLine = vectAll.get(curIndex);
			curLineTrim = curLine.trim();

			if(curLineTrim.startsWith("["))
			{

				//				if(curLineTrim.length()<=1)
				//				if(curLineTrim.equals(this.termStart))
				break;

			}



			if(curLineTrim.startsWith("id:"))
			{
				id = curLineTrim.substring(4).trim();

			}
			else if(curLineTrim.startsWith("name:"))
			{
				name = curLineTrim.substring(6).trim();

			}
			else if(curLineTrim.startsWith("namespace:"))
			{
				namespace = curLineTrim.substring(11).trim();

			}else if(curLineTrim.startsWith("is_a:") ) {

				tmp = ConstantValue.patWhiteSpace.split(curLineTrim);
				bufISA.append(tmp[1]+",");

			}else if(curLineTrim.startsWith("relationship:"))
			{

				tmp = ConstantValue.patWhiteSpace.split(curLineTrim);
				bufPartOf.append(tmp[2]+",");
			}

			curIndex++;
		}

		String finalISA = "";
		String finalPARTOF= "";

		if(bufISA.length()>0)
		{
			finalISA = bufISA.substring(0,bufISA.length()-1);
		}else
		{
			finalISA ="";
		}

		if(bufPartOf.length()>0)
		{
			finalPARTOF = bufPartOf.substring(0,bufPartOf.length()-1);
		}else
		{
			finalPARTOF ="";
		}




		resultLine=id+"\t" + name + "\t" + namespace  
				+ "\t" + finalISA  
				+ "\t" + finalPARTOF ;





		return resultLine;
	}


	void doProcessing()
	{
		loadAll();
		doParsing();

	}

	public static void main(String[] args) {

		OboToTable obj = new OboToTable();

//		obj.init( "go-basic.obo", "go-basic.obo.tsv");
		//		obj.init( "test.obo", "go-basic.obo.tsv");

				obj.init(args[0], args[1]);

		obj.doProcessing();

	}
}
