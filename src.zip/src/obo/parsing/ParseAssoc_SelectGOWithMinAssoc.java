package obo.parsing;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class ParseAssoc_SelectGOWithMinAssoc {


	String fnmAssoc;
	String fnmStatististics;
	String minAssoc;
	String fnmOut;


	Set<String> set_SelectedGO = new LinkedHashSet<String>();


	void subselectGOAssociation()
	{


		String tmp[];
		String curLine;
		String curRes;

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAssoc);
		String curUniAcc, curUniName, curGO="";
		String source="";
		int totColumn;

		StringBuffer resBuf = new StringBuffer();

		for( int i= 0;  i<vectAll.size(); i++)
		{

			curLine = vectAll.get(i);
			
			
			if(curLine.startsWith("!"))
			{
				resBuf.append( curLine + "\n");
			}
			else
			{
				tmp = ConstantValue.patTab.split(curLine);
				totColumn = tmp.length;

				source = tmp[0];
				curUniAcc = tmp[1];

				if( !source.equals("UniProtKB") )
					continue;

				// curGO = tmp[3];
				// There are some cases where GO:NNNNNNN is not at 4th tab-delimitted column

				for( int j=2; j<totColumn ;j++)
				{
					if( tmp[j].startsWith("GO:"))
					{
						curGO = tmp[j];
						break;
					}

				}


				if( set_SelectedGO.contains(  curGO))
				{
					resBuf.append( curLine + "\n");

				}else{

				}


			}

		}

		
		
		CommonFunction.writeContentToFile(this.fnmOut, resBuf + "");



	}



	void loadStatistics()
	{

		Vector<String> vectStat = CommonFunction.readlinesOfAfile(this.fnmStatististics);


		String tmp[] , tmpGOlist[];
		String curLine, curGO;

		int totAssoc;
		int thrMin = Integer.parseInt(this.minAssoc);

		for( int i=0; i<vectStat.size();i++)
		{
			curLine = vectStat.get(i);
			tmp = ConstantValue.patTab.split( curLine );

			curGO = tmp[0];
			totAssoc = Integer.parseInt(tmp[1]);
			tmpGOlist = ConstantValue.patSemiColon_Comma.split(tmp[2]) ;

			if(totAssoc >= thrMin)
			{
				set_SelectedGO.add( curGO);
			}




		}
		
		
		System.out.println("total GO having min assoc : " + set_SelectedGO.size() );
		

	}


	


	public ParseAssoc_SelectGOWithMinAssoc(String fnmAssoc,
			String fnmStatististics, String minAssoc, String fnmOut) {
		super();
		this.fnmAssoc = fnmAssoc;
		this.fnmStatististics = fnmStatististics;
		this.minAssoc = minAssoc;
		this.fnmOut = fnmOut;
	}



	void doProcessing()
	{

		loadStatistics();
		subselectGOAssociation();
	}


	public static void main(String[] args) {

		ParseAssoc_SelectGOWithMinAssoc obj = new ParseAssoc_SelectGOWithMinAssoc(args[0], args[1], args[2], args[3]);
		
		
		
		obj.doProcessing();

	}


}
