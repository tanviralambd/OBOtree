package obo.parsing;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class CreateParentChild {


	String fnmIn;
	String fnmOut;




	LinkedHashMap<String, Set<String>> lhm_parent_childs = new LinkedHashMap<String, Set<String>>();

	StringBuffer bufFinal = new StringBuffer();



	/*
	 *  Parent | depth | Child
	 */
	void BFScall( String curParent , int level)
	{


		if( ! lhm_parent_childs.containsKey(curParent))
			return;

		Set<String> mySet = lhm_parent_childs.get(curParent);
		int setSize = mySet.size();

		if(setSize<=0)
			return ;

		String[] arrChild = (String[]) mySet.toArray(new String[setSize]);

		for(int c=0; c < setSize;c++)
		{
			bufFinal.append(curParent + "\t" + level + "\t"+  arrChild[c] +"\n");
		}


		for(int c=0; c < setSize;c++)
		{
			BFScall( arrChild[c] , (level+1));
		}


	}


	void loadAll()
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmIn);

		String tmp[];
		String curPar,curChild;
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			curChild = tmp[0];
			curPar = tmp[2];

			if(curPar.equals("-1"))
				System.out.println("Found -1");


			if(lhm_parent_childs.containsKey(curPar))
			{
				lhm_parent_childs.get(curPar).add(curChild) ;
			}else
			{
				Set tmpSet = new LinkedHashSet();
				tmpSet.add(curChild);
				lhm_parent_childs.put(curPar, tmpSet);

			}



		}



	}

	void writeResult()
	{


		Set<String> setRoot = lhm_parent_childs.get( Integer.toString(ConstantValue.GO_ROOT ) );

		String[] arrRoot = (String[]) setRoot.toArray(new String[setRoot.size()]);
		String rootVaue= arrRoot[0];

		//		bufFinal.append("Parent" + "\t" + "level" + "\t"+  "Child" +"\n");

		BFScall( Integer.toString(ConstantValue.GO_ROOT )  , 0 ) ;

		CommonFunction.writeContentToFile(this.fnmOut, bufFinal+"");


	}


	void doProcessing()
	{
		loadAll();
		writeResult();
	}




	public CreateParentChild(String fnmIn, String fnmOut) {
		super();
		this.fnmIn = fnmIn;
		this.fnmOut = fnmOut;
	}

	public static void main(String[] args) {

		CreateParentChild obj = new CreateParentChild(args[0] , args[1]);

//				CreateParentChild obj = new CreateParentChild("go-basic.obo.BP" , "go-basic.obo.BP.parentchild");


		obj.doProcessing();

	}

}
