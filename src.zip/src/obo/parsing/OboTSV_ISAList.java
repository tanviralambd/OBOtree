package obo.parsing;

import java.util.LinkedHashMap;

public class OboTSV_ISAList {

	
	String fnmTSV;
	String fnmISAlist;
	
	
	
	
	
	void doProcessing()
	{
		
	}
	
	public static void main(String[] args) {
		
	}
	
	
}
