package obo.parsing;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class Uniprot_GO_mapping {


	String fnmAssociationFromGO;
	String mapping_UniAcc_Uniname;
	String foutMapping;
	String foutMappingGO_gene;
	



	LinkedHashMap<String, String> lhm_UniAcc_UniName = new LinkedHashMap<String, String>();

	LinkedHashMap<String, String> lhm_UniAcc_ListGO = new LinkedHashMap<String, String>();

	LinkedHashMap<String, Set<String>> lhm_GO_UniName = new LinkedHashMap<String, Set<String>>();

	

	void load_UniACC_UniName()
	{
		Vector<String> vectMap = CommonFunction.readlinesOfAfile(this.mapping_UniAcc_Uniname);
		String tmp[];
		String uniAcc, uniName;
		for( int i=0 ;  i<vectMap.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectMap.get(i));
			uniAcc  = tmp[0];
			uniName = tmp[1];

			if( lhm_UniAcc_UniName.containsKey(uniAcc))
			{
				System.out.println("already exist: " + uniAcc);
			}else
			{
				lhm_UniAcc_UniName.put(uniAcc, uniName) ;
			}


		}



	}


	void generate_Uniname_GOlist()
	{


		String tmp[];
		String curLine;
//		int skipheadTotLine = 0;
		String curRes;

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAssociationFromGO);
		String curUniAcc, curUniName, curGO="";
		String source="";
		int totColumn;

		StringBuffer resBuf = new StringBuffer();

		for( int i= 0;  i<vectAll.size(); i++)
		{

			curLine = vectAll.get(i);
			if(curLine.startsWith("!"))
			{
				continue;
			}

			tmp = ConstantValue.patTab.split(curLine);
			totColumn = tmp.length;

			source = tmp[0];
			curUniAcc = tmp[1];

			if( !source.equals("UniProtKB") )
				continue;

			//			curGO = tmp[3];
			// There are some cases where GO:NNNNNNN is not at 4th tab-delimitted column

			for( int j=2; j<totColumn ;j++)
			{
				if( tmp[j].startsWith("GO:"))
				{
					curGO = tmp[j];
					break;
				}

			}





			/*
			 *  Append into Result: acc --> GO
			 */

			if( lhm_UniAcc_ListGO.containsKey(curUniAcc))
			{
				curRes = lhm_UniAcc_ListGO.get(curUniAcc);
				lhm_UniAcc_ListGO.put(curUniAcc, curRes + ";" + curGO  );
			}else{
				lhm_UniAcc_ListGO.put(curUniAcc, curGO  );
			}

			
			/*
			 *  Append into Result:  GO --> Name
			 */
			
			
			if(lhm_UniAcc_UniName.containsKey(curUniAcc))
			{
			
				curUniName = lhm_UniAcc_UniName.get(curUniAcc) ;
				
				if( lhm_GO_UniName.containsKey(  curGO))
				{
					Set curGeneList = lhm_GO_UniName.get(curGO);
					curGeneList.add(curUniName);
					lhm_GO_UniName.put(curGO, curGeneList  );
				}else{
					Set curGeneList = new LinkedHashSet<String>();
					curGeneList.add(curUniName);
					lhm_GO_UniName.put( curGO , curGeneList );
				}
				
				
			}

			
			

		}




	}

	void doProcessing()
	{

		load_UniACC_UniName();

		generate_Uniname_GOlist();

		writeList_Gene_GOlist();
		
		writeList_GO_Genelist();
	}




	public Uniprot_GO_mapping(String fnmMappingFromGO,
			String mapping_UniAcc_Uniname, String foutMapping) {
		super();
		this.fnmAssociationFromGO = fnmMappingFromGO;
		this.mapping_UniAcc_Uniname = mapping_UniAcc_Uniname;
		this.foutMapping = foutMapping;
	}


	


	public Uniprot_GO_mapping(String fnmAssociationFromGO,
			String mapping_UniAcc_Uniname, String foutMapping,
			String foutMappingGO_gene) {
		super();
		this.fnmAssociationFromGO = fnmAssociationFromGO;
		this.mapping_UniAcc_Uniname = mapping_UniAcc_Uniname;
		this.foutMapping = foutMapping;
		this.foutMappingGO_gene = foutMappingGO_gene;
	}


	void writeList_Gene_GOlist()
	{
		/*
		 *  Write the result
		 */

		String uniName;
		StringBuffer resBuf = new StringBuffer();
		StringBuffer resBufStat = new StringBuffer();
		

		Set set = lhm_UniAcc_ListGO.entrySet();
		System.out.println("Total Unique protein in GO file:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String protACC = (String)me.getKey();

			if(lhm_UniAcc_UniName.containsKey(protACC))
			{
				uniName = lhm_UniAcc_UniName.get(protACC);
			}else
			{
				uniName = ConstantValue.noneStr;
			}

			String goList = (String) me.getValue();
			String tmpGO[]= ConstantValue.patSemiColon.split(goList);
			Set setGO = new LinkedHashSet<String>();
			for(int j=0 ; j< tmpGO.length ; j++)
			{
				setGO.add(tmpGO[j]);
			}



			resBuf.append(protACC + "\t" + uniName + "\t"  );
			resBufStat.append(protACC + "\t" + uniName + "\t"  );



			String[] arr = (String[]) setGO.toArray(new String[setGO.size()]);
			int setSize = arr.length;
			
			resBufStat.append(setSize + "\n");
			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(arr[c]+ "\n");
				else
					resBuf.append(arr[c]+ ConstantValue.seperatorList );

			} 


		}



		CommonFunction.writeContentToFile(this.foutMapping, resBuf+"");
		
		CommonFunction.writeContentToFile(this.foutMapping+".stat", resBufStat+"");
		
		
	}



	void writeList_GO_Genelist()
	{
		

		String uniName;
		StringBuffer resBuf = new StringBuffer();
		

		Set set = lhm_GO_UniName.entrySet();
		System.out.println("Total Unique GO terms in GO file:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String curGO = (String)me.getKey();
			Set  protNameList  = (Set<String>) me.getValue();
		

			String[] arr = (String[]) protNameList.toArray(new String[protNameList.size()]);
			int setSize = arr.length;
			
			resBuf.append(curGO + "\t" + setSize + "\t"  );

			for(int c=0; c < setSize;c++)
			{
				if(c==setSize-1)
					resBuf.append(arr[c]+ "\n");
				else
					resBuf.append(arr[c]+ ConstantValue.seperatorList );

			} 


		}


		CommonFunction.writeContentToFile(this.foutMappingGO_gene, resBuf+"");
		
		
	}



	public static void main(String[] args) {

		Uniprot_GO_mapping obj = new Uniprot_GO_mapping(args[0], args[1] , args[2] ,args[3]);

		//		Uniprot_GO_mapping obj = new Uniprot_GO_mapping("gene_association.goa_ref_human", 
		//				"HUMAN_9606_idmapping.dat_UniAcc_UniName.txt" , 
		//				"gene_association.goa_ref_human.UniprotList");
		//		
		obj.doProcessing();

		//		String a = "a_HUMAN";

	}

}

