package obo.parsing;

import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class Uniprot_GO_SubselectHavingNterms {

	
	String fnmInputList;
	int minNoGOTerm;
	String fnmOutputList;
	
	
	public Uniprot_GO_SubselectHavingNterms(String fnmInputList,
			int minNoGOTerm, String fnmOutputList) {
		super();
		this.fnmInputList = fnmInputList;
		this.minNoGOTerm = minNoGOTerm;
		this.fnmOutputList = fnmOutputList;
	}


	void doProecessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInputList);
		StringBuffer buf = new StringBuffer();
		
		String tmp[] , tmpGOlist[];
		String curLine;
		
		for( int i=0; i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);
			tmp = ConstantValue.patTab.split( curLine );
			
			tmpGOlist = ConstantValue.patSemiColon_Comma.split(tmp[2]) ;
			
			if( tmpGOlist.length >= this.minNoGOTerm)
			{
				buf.append( curLine + "\n") ;
			}
			
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOutputList, buf+"");
	}
	
	
	public static void main(String[] args) {
		
		
		Uniprot_GO_SubselectHavingNterms obj = new Uniprot_GO_SubselectHavingNterms(args[0], Integer.parseInt(args[1]), args[2]);
		
		obj.doProecessing();
		
		
	}
	
}
