package obo.parsing;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class Uniprot_GO_mappingV1 {


	String fnmAssociationFromGO;
	String mapping_UniAcc_Uniname;
	String foutMapping;



	LinkedHashMap<String, String> lhm_UniAcc_UniName = new LinkedHashMap<String, String>();

	LinkedHashMap<String, String> lhm_UniAcc_ListGO = new LinkedHashMap<String, String>();



	void load_UniACC_UniName()
	{
		Vector<String> vectMap = CommonFunction.readlinesOfAfile(this.mapping_UniAcc_Uniname);
		String tmp[];
		String uniAcc, uniName;
		for( int i=0 ;  i<vectMap.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectMap.get(i));
			uniAcc  = tmp[0];
			uniName = tmp[1];

			if( lhm_UniAcc_UniName.containsKey(uniAcc))
			{
				System.out.println("already exist: " + uniAcc);
			}else
			{
				lhm_UniAcc_UniName.put(uniAcc, uniName) ;
			}


		}



	}


	void generate_Uniname_GOlist()
	{


		String tmp[];
		String curLine;
		int skipheadTotLine = 59;
		String curRes;

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAssociationFromGO);
		String uniAcc, uniName, curGO;

		StringBuffer resBuf = new StringBuffer();

		for( int i=0;  i<vectAll.size(); i++)
		{

			curLine = vectAll.get(i);
			if(curLine.startsWith("!"))
			{
				continue;
			}

			tmp = ConstantValue.patTab.split(curLine);

			uniAcc = tmp[1];
			curGO = tmp[3];




			/*
			 *  Append into Result
			 */

			if( lhm_UniAcc_ListGO.containsKey(uniAcc))
			{
				curRes = lhm_UniAcc_ListGO.get(uniAcc);
				lhm_UniAcc_ListGO.put(uniAcc, curRes + ";" + curGO  );
			}else{
				lhm_UniAcc_ListGO.put(uniAcc, curGO  );
			}


		}




	}

	void doProcessing()
	{

		load_UniACC_UniName();

		generate_Uniname_GOlist();

		writeList();
	}




	public Uniprot_GO_mappingV1(String fnmMappingFromGO,
			String mapping_UniAcc_Uniname, String foutMapping) {
		super();
		this.fnmAssociationFromGO = fnmMappingFromGO;
		this.mapping_UniAcc_Uniname = mapping_UniAcc_Uniname;
		this.foutMapping = foutMapping;
	}




	void writeList()
	{
		/*
		 *  Write the result
		 */

		String uniName;
		StringBuffer resBuf = new StringBuffer();

		Set set = lhm_UniAcc_ListGO.entrySet();
		System.out.println("Total Unique protein in GO file:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String protACC = (String)me.getKey();

			if(lhm_UniAcc_UniName.containsKey(protACC))
			{
				uniName = lhm_UniAcc_UniName.get(protACC);
			}else
			{
				uniName = ConstantValue.noneStr;
			}

			String goList = (String) me.getValue();
			String tmpGO[]= ConstantValue.patSemiColon.split(goList);
			Set setGO = new LinkedHashSet<String>();
			for(int j=0 ; j< tmpGO.length ; j++)
			{
				setGO.add(tmpGO[j]);
			}



			resBuf.append(protACC + "\t" + uniName + "\t"  );


			for( int s=0 ; s<setGO.size();s++)
			{
				if(s== setGO.size()-1){

					resBuf.append(goList + "\n");
				}else
				{
					resBuf.append(goList + ConstantValue.seperatorList  );
				}
			}



		}



		CommonFunction.writeContentToFile(this.foutMapping, resBuf+"");
	}




	public static void main(String[] args) {

		Uniprot_GO_mappingV1 obj = new Uniprot_GO_mappingV1(args[0], args[1] , args[2]);

		//		Uniprot_GO_mappingV1 obj = new Uniprot_GO_mappingV1("gene_association.goa_ref_human", 
		//				"HUMAN_9606_idmapping.dat_UniAcc_UniName.txt" , 
		//				"gene_association.goa_ref_human.UniprotList");
		//		
		obj.doProcessing();


		//		String a = "a_HUMAN";






	}

}
