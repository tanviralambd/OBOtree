package obo.EnrichmentParsing;

import java.util.LinkedHashMap;
import java.util.Vector;

import obo.common.CommonFunction;
import obo.constant.ConstantValue;

public class GO_GOdescription {

	
	String fnmInput;
	String fnmGO_Desc;
	
	String fnmOutput;
	
	
	LinkedHashMap<String, String> lhm_goid_godesc = new LinkedHashMap<String, String>();
	
	
	void loadMap()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmGO_Desc);
		String tmp[];
		for( int i=0 ; i< vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			lhm_goid_godesc.put(tmp[0], tmp[1] ) ;
			
		}
		
		
		
	}
	
	
	void writeDescription()
	{
		
		double fdr=0.0;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		
		StringBuffer resBuf = new StringBuffer();
		
		String tmp[];
		int totCol;
		for( int i=1 ; i< vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			totCol = tmp.length;
			
			fdr = Double.parseDouble( tmp[totCol-1] );
			
			if( fdr <= 0.05 )
			{
				
				if( lhm_goid_godesc.containsKey(tmp[0] ))
				{
					resBuf.append( tmp[0] + "\t"
								+ lhm_goid_godesc.get(tmp[0]) + "\t" 
								+ tmp[totCol-1] + "\n");
				}
				
			}
			
			
			
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOutput, resBuf+"");
	}
	
	void doProcessing()
	{
		loadMap();
		
		writeDescription();
	}
	
	
	
	public GO_GOdescription(String fnmInput, String fnmGO_Desc, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmGO_Desc = fnmGO_Desc;
		this.fnmOutput = fnmOutput;
	}


	public static void main(String[] args) {
		
		GO_GOdescription obj = new GO_GOdescription(args[0],args[1],args[2]);
		
		obj.doProcessing();
		
	}
	
}
