package obo.bean;

import java.util.Arrays;
import java.util.Vector;

public class MotifHOCOMOCO {

	String motifid;
	int motiflen;
	double pvalue;
	double motifthr;
	/*
	 *  4 by MOTIFLEN
	 */
	double PWM[][];
	
	
//	************************
//	ID: AHR_si
//	length: 9
//	pvalue: 0.000500
//	threshold: 0.862735
//	0.039073	0.010491	0.020945	0.002456	0.000000	0.003319	0.000000	0.000000	0.041548	
//	0.017610	0.011449	0.042323	0.001270	0.145013	0.000762	0.003319	0.000000	0.064498	
//	0.054407	0.033431	0.019971	0.140678	0.001440	0.144066	0.000678	0.148486	0.015585	
//	0.037395	0.093115	0.065247	0.004081	0.002033	0.000339	0.144489	0.000000	0.026854	

	public String toStringHOCOMOCOmotif()
	{
		
		StringBuffer buf = new StringBuffer();
		buf.append("************************"+"\n");
		buf.append("ID: " + this.motifid+"\n");
		buf.append("length: " + this.motiflen+"\n");
		buf.append("pvalue: " + this.pvalue+"\n");
		buf.append("threshold: " + this.motifthr+"\n");
			
		
		for( int  j=0 ; j <this.motiflen ;  j++)
		{
			buf.append( this.PWM[0][j] + "\t"  );
		}
		buf.append("\n");
		
		
		for( int  j=0 ; j <this.motiflen ;  j++)
		{
			buf.append( this.PWM[1][j] + "\t"  );
		}
		buf.append("\n");
		
		for( int  j=0 ; j <this.motiflen ;  j++)
		{
			buf.append( this.PWM[2][j] + "\t"  );
		}
		buf.append("\n");
		
		for( int  j=0 ; j <this.motiflen ;  j++)
		{
			buf.append( this.PWM[3][j] + "\t"  );
		}
//		buf.append("\n");
		
		
		return buf+"";
	}
	
	public MotifHOCOMOCO( double thr, Vector<Double> vecA ,   Vector<Double> vecC ,  Vector<Double> vecG ,  Vector<Double> vecT  , int doNorm )
	{

		this.motifthr = thr;
		this.motiflen = vecA.size();
		this.PWM = new double[4][this.motiflen ];
		
		if( doNorm == 0)
		{
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
						}	
						break;	
					default:
						break;
					}					
							
			}
			
		}else // do normalization
		{
			
			double motifMax[] = new double[this.motiflen];
			for(int j=0 ; j<this.motiflen; j++)
			{
				double tmp[]= new double[4];
				tmp[0] =  vecA.get(j);
				tmp[1]  = vecC.get(j);
				tmp[2]  = vecG.get(j);
				tmp[3]  = vecT.get(j);
				
				double maximum = 0.0;
				for(int k=0 ; k <4 ; k++)
				{
					if( maximum < tmp[k] )
						maximum = tmp[k];					
				}
				motifMax[j] = maximum;
			}	
			
			double sumMax = 0.0;
			for (int i=0 ;  i<this.motiflen ; i++)
			{
				sumMax += motifMax[i];
			}
			
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
							this.PWM[i][j] /= sumMax ;
							
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
							this.PWM[i][j] /= sumMax;
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;	
					default:
						break;
					}					
							
			}
			
			
			
		}
		
		
	}


	public MotifHOCOMOCO( String motifID ,double thr, Vector<Double> vecA ,   Vector<Double> vecC ,  Vector<Double> vecG ,  Vector<Double> vecT  , int doNorm )
	{
		this.motifid = motifID;
		this.motifthr = thr;
		this.motiflen = vecA.size();
		this.PWM = new double[4][this.motiflen ];
		
		if( doNorm == 0)
		{
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
						}	
						break;	
					default:
						break;
					}					
							
			}
			
		}else // do normalization
		{
			
			double motifMax[] = new double[this.motiflen];
			for(int j=0 ; j<this.motiflen; j++)
			{
				double tmp[]= new double[4];
				tmp[0] =  vecA.get(j);
				tmp[1]  = vecC.get(j);
				tmp[2]  = vecG.get(j);
				tmp[3]  = vecT.get(j);
				
				double maximum = 0.0;
				for(int k=0 ; k <4 ; k++)
				{
					if( maximum < tmp[k] )
						maximum = tmp[k];					
				}
				motifMax[j] = maximum;
			}	
			
			double sumMax = 0.0;
			for (int i=0 ;  i<this.motiflen ; i++)
			{
				sumMax += motifMax[i];
			}
			
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
							this.PWM[i][j] /= sumMax ;
							
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
							this.PWM[i][j] /= sumMax;
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;	
					default:
						break;
					}					
							
			}
			
			
			
		}
		
		
	}
	
	
	/*
	 *   FOR TRACK  ONLY
	 */
	public MotifHOCOMOCO( String motifID ,  String spval, double thr, Vector<Double> vecA ,   Vector<Double> vecC ,  Vector<Double> vecG ,  Vector<Double> vecT )
	{
		this.motifid = motifID;
		
		this.motiflen = vecA.size();
		this.pvalue = Double.parseDouble(spval);
		this.motifthr = thr;
		this.PWM = new double[4][this.motiflen ];
		

			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
						}	
						break;	
					default:
						break;
					}					
							
			}
			
		}
		
		

//	public String toString()
//	{
//		StringBuffer buf = new StringBuffer();
//		
//		buf.append("************************" + "\n");
//		buf.append("ID:"+"\t" + this.motifid+ "\n");
//		buf.append("length:"+"\t" + this.motiflen+ "\n");
//		buf.append("pvalue:"+"\t" + "0.000500"+ "\n");
//		buf.append("threshold:"+"\t" + this.motifthr+ "\n");
//		buf.append("ID:"+"\t" + this.motifid+ "\n");
//		buf.append("ID:"+"\t" + this.motifid+ "\n");
//		
//		
//		
//		return buf+"";
//	}


	public int getMotiflen() {
		return motiflen;
	}

	public void setMotiflen(int motiflen) {
		this.motiflen = motiflen;
	}

	public double getMotifthr() {
		return motifthr;
	}

	public void setMotifthr(double motifthr) {
		this.motifthr = motifthr;
	}

	public double[][] getPWM() {
		return PWM;
	}


	public void setPWM(double[][] pWM) {
		PWM = pWM;
	}
	
	public String getMotifid() {
		return motifid;
	}



	public void setMotifid(String motifid) {
		this.motifid = motifid;
	}
	
	public double getPvalue() {
		return pvalue;
	}

	public void setPvalue(double pvalue) {
		this.pvalue = pvalue;
	}
	
	
}
