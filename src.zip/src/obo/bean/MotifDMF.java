package obo.bean;

import java.util.Vector;

public class MotifDMF {

	String motifid;


	String consensus;
	int motiflen;
	double motifthr;


	double cCov;
	double ncCov;
	String source;
	double score;
	
	/*
	 *  4 by MOTIFLEN
	 */
	double PWM[][];

	
	/* 
	 *  distance from IdealPoint
	 */
	double distanceValue ;
	
	String A;
	String C;
	String G;
	String T;

	/*
	 *  USEFUL FOR SOME SPECIAL CASES. So, not included in constructor
	 */
	
	double qvalueMatch=0.0;
	


	
	
	/*
	 *  FOR TRACK ONLY
	 */
	public MotifDMF(String id, String consensus, int len, double thr,
			double cCov, double ncCov, String source, double score) {
		super();
		this.motifid = id;
		this.consensus = consensus;
		this.motiflen = len;
		this.motifthr = thr;
		this.cCov = cCov;
		this.ncCov = ncCov;
		this.source = source;
		this.score = score;
//		A = a;
//		C = c;
//		G = g;
//		T = t;
	}

	private void DMFmoti() {
		

	}
	
	public MotifDMF(String id, double cCov, double ncCov, double score,
			String source, String consensus) {
		super();
		this.motifid = id;
		this.cCov = cCov;
		this.ncCov = ncCov;
		this.score = score;
		this.source = source;
		this.consensus = consensus;
	}

	public MotifDMF(String id, double cCov, double ncCov, double score,
			String source, String consensus,String A, String C, String G, String T) {
		super();
		this.motifid = id;
		this.cCov = cCov;
		this.ncCov = ncCov;
		this.score = score;
		this.source = source;
		this.consensus = consensus;
		this.A = A;
		this.C = C;
		this.G = G;
		this.T = T;
	}

	public MotifDMF(String id, double cCov, double ncCov, double score,
			String source, String consensus,String A, String C, String G, String T, double distValue) {
		super();
		this.motifid = id;
		this.cCov = cCov;
		this.ncCov = ncCov;
		this.score = score;
		this.source = source;
		this.consensus = consensus;
		this.A = A;
		this.C = C;
		this.G = G;
		this.T = T;
		this.distanceValue = distValue;
	}

	
	
	public MotifDMF(  String motifID ,double thr, Vector<Double> vecA ,   Vector<Double> vecC ,  Vector<Double> vecG ,  Vector<Double> vecT  , int doNorm )
	{
		this.motifid = motifID;
		this.motifthr = thr;
		this.motiflen = vecA.size();
		this.PWM = new double[4][this.motiflen ];
		
		if( doNorm == 0)
		{
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
						}	
						break;	
					default:
						break;
					}					
							
			}
			
		}else // do normalization
		{
			
			double motifMax[] = new double[this.motiflen];
			for(int j=0 ; j<this.motiflen; j++)
			{
				double tmp[]= new double[4];
				tmp[0] =  vecA.get(j);
				tmp[1]  = vecC.get(j);
				tmp[2]  = vecG.get(j);
				tmp[3]  = vecT.get(j);
				
				double maximum = 0.0;
				for(int k=0 ; k <4 ; k++)
				{
					if( maximum < tmp[k] )
						maximum = tmp[k];					
				}
				motifMax[j] = maximum;
			}	
			
			double sumMax = 0.0;
			for (int i=0 ;  i<this.motiflen ; i++)
			{
				sumMax += motifMax[i];
			}
			
			for(int i=0;  i< 4 ;i++)
			{				
					switch (i) {
					case 0:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecA.get(j);
							this.PWM[i][j] /= sumMax ;
							
						}				
						break;
						
					case 1:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecC.get(j);
							this.PWM[i][j] /= sumMax;
						}	
						break;
						
					case 2:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecG.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;
						
					case 3:
						for(int j=0 ; j<this.motiflen; j++)
						{
							this.PWM[i][j] = vecT.get(j);
							this.PWM[i][j] /= sumMax ;
						}	
						break;	
					default:
						break;
					}					
							
			}
			
			
		}
		
		
	}
	

//	*******************************************************
//	ID: DMF0288
//	Consensus: CCCTTCTC
//	length: 8
//	Threshold: 0.800000
//	Coverage: 0.997122
//	BGCoverage: 0.992800
//	source: C
//	score: 9.912700E-06
//	241	428	78	1735	66	10	64	31
//	8536	8337	9480	1267	342	9607	420	9543
//	319	183	10	920	170	18	30	50
//	606	754	134	5780	9124	67	9188	78
//

	public String printDMFmotif()
	{
		
		StringBuffer buf = new StringBuffer();
		buf.append("*******************************************************"+"\n");
		buf.append("ID: " + this.motifid+"\n");
		buf.append("Consensus:"+this.consensus+"\n");
		buf.append("length: " + this.motiflen+"\n");
		buf.append("Threshold: "+ this.motifthr+"\n");
		buf.append("Coverage: "+this.cCov +"\n");
		buf.append("BGCoverage: "+this.ncCov +"\n" );
		buf.append("source: "+this.source +"\n");
		buf.append("score: " + this.score+"\n");
			
		buf.append(A+"\n");
		buf.append(C+"\n");
		buf.append(G+"\n");
		buf.append(T+"\n");
		
		
		return buf+"\n";
	}
	


	
	public int getMotiflen() {
		return motiflen;
	}

	public void setMotiflen(int motiflen) {
		this.motiflen = motiflen;
	}

	public double getcCov() {
		return cCov;
	}



	public void setcCov(double cCov) {
		this.cCov = cCov;
	}



	public double getNcCov() {
		return ncCov;
	}



	public void setNcCov(double ncCov) {
		this.ncCov = ncCov;
	}



	public double getScore() {
		return score;
	}



	public void setScore(double score) {
		this.score = score;
	}



	public String getSource() {
		return source;
	}



	public void setSource(String source) {
		this.source = source;
	}



	public String getConsensus() {
		return consensus;
	}



	public void setConsensus(String consensus) {
		this.consensus = consensus;
	}



	public String getA() {
		return A;
	}


	public void setA(String a) {
		A = a;
	}


	public String getC() {
		return C;
	}


	public void setC(String c) {
		C = c;
	}


	public String getG() {
		return G;
	}


	public void setG(String g) {
		G = g;
	}


	public String getT() {
		return T;
	}


	public void setT(String t) {
		T = t;
	}
	
	public double getDistanceValue() {
		return distanceValue;
	}


	public void setDistanceValue(double distanceValue) {
		this.distanceValue = distanceValue;
	}
	
	
	public double getQvalueMatch() {
		return qvalueMatch;
	}

	public void setQvalueMatch(double qvalueMatch) {
		this.qvalueMatch = qvalueMatch;
	}
	



	public double[][] getPWM() {
		return PWM;
	}

	public void setPWM(double[][] pWM) {
		PWM = pWM;
	}
	
	public String getMotifid() {
		return motifid;
	}

	public void setMotifid(String motifid) {
		this.motifid = motifid;
	}
	

	public double getMotifthr() {
		return motifthr;
	}

	public void setMotifthr(double motifthr) {
		this.motifthr = motifthr;
	}
	
}
