package obo.bean;



public class ChromatinState {

	String  stateChrom;
	Integer stateStart;
    Integer stateEnd;
    Integer stateNo;


    
	public ChromatinState(String stateChrm, Integer stateStart, Integer stateEnd, Integer stNo )
	{
		super();
		this.stateChrom = stateChrm;
		this.stateStart = stateStart;
		this.stateEnd = stateEnd;
		this.stateNo = stNo ;

	}



	public Integer getStateNo() {
		return stateNo;
	}



	public void setStateNo(Integer stateNo) {
		this.stateNo = stateNo;
	}



	public String getStateChrom() {
		return stateChrom;
	}



	public void setStateChrom(String stateChrom) {
		this.stateChrom = stateChrom;
	}



	public Integer getStateStart() {
		return stateStart;
	}



	public void setStateStart(Integer stateStart) {
		this.stateStart = stateStart;
	}



	public Integer getStateEnd() {
		return stateEnd;
	}



	public void setStateEnd(Integer stateEnd) {
		this.stateEnd = stateEnd;
	}
	
	

	
    
    
}
